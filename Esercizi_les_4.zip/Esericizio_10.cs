﻿/* Questo programma chiede all'utente di inserire il numero di elementi in una sequenza
quindi chiede all'utente di inserire ogni elemento della sequenza. 
Controlla se due elementi consecutivi sono uguali. 
Se ne trova uno, memorizza la posizione del primo elemento di quella sequenza e esce dal ciclo. 
Se non viene trovata alcuna sequenza di numeri uguali, stampa un messaggio indicando quest'ultimo. */

using System;

class ClassMain
{
    static void Main(string[] args)
    {
        // Richiedere all'utente di inserire il numero di elementi nella sequenza
        Console.Write("Immettere il numero di elementi nella sequenza: ");
        int n = int.Parse(Console.ReadLine()); // Funzione presa da Microsoft learn

        // Inizializza un array per memorizzare gli elementi della sequenza
        int[] sequence = new int[n];

        // Richiedere all'utente di inserire gli elementi della sequenza
        for (int i = 0; i < n; i++)
        {
            Console.Write("Inserisci elemento {0}: ", i + 1);
            sequence[i] = int.Parse(Console.ReadLine());
        }

        // Inizializza una variabile per memorizzare la posizione del primo elemento di una sequenza di numeri uguali
        int pos = -1;

        // Scorrere gli elementi della sequenza
        for (int i = 0; i < n - 1; i++)
        {
            // Controlla se l'elemento corrente è uguale all'elemento successivo
            if (sequence[i] == sequence[i + 1])
            {
                // In tal caso, imposta la posizione sull'indice corrente ed esci dal ciclo
                pos = i;
                break;
            }
        }

        // Controlla se la posizione è stata impostata
        if (pos != -1)
        {
            // In tal caso, stampare la posizione
            Console.WriteLine("Il primo elemento di una sequenza di numeri uguali è in posizione {0}", pos + 1);
        }
        else
        {
            // In caso contrario, stampare un messaggio indicante che non è stata trovata alcuna sequenza di numeri uguali
            Console.WriteLine("Non è stata trovata alcuna sequenza di numeri uguali.");
        }
    }
}

