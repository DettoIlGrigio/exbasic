﻿using System;

class ClassMain
{
    // Funzione per trovare i fattori primi di un dato intero
    static void factorize(int n)
    {
        // Edge case per 1
        if (n == 1)
        {
            return;
        }

        // Iterare da 2 a sqrt(n) (funzione presa da Microsoft Learn)
        for (int i = 2; i <= Math.Sqrt(n); i++)
        {
            // Mentre n è divisibile per i, divido n per i e stampa i
            while (n % i == 0)
            {
                Console.Write(i + " ");
                n /= i;
            }
        }

        // Se n è ancora maggiore di 1, è un numero primo
        if (n > 1)
        {
            Console.Write(n);
        }
    }

    // Funzione Main 
    static void Main(string[] args)
    {
        Console.Write("Immettere un numero intero positivo: ");
        int n = int.Parse(Console.ReadLine());

        // Chiamo la funzione factorize
        factorize(n);
    }
}

