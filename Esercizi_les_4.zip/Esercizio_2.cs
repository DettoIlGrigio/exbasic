﻿using System;

class ClassMain
{
    static void Main(string[] args)
    {
        // chiediamo all'utente di inserire un numero intero non negativo
        Console.WriteLine("Inserisci un numero intero non negativo:");
        int n = int.Parse(Console.ReadLine());

        // inizializziamo una variabile per tenere traccia del fattoriale
        int factorial = 1;

        // calcoliamo il fattoriale utilizzando un ciclo
        for (int i = 1; i <= n; i++)
        {
            factorial *= i;
        }

        // stampiamo il risultato
        Console.WriteLine("Il fattoriale di " + n + " è: " + factorial);
        Console.ReadLine();
    }
}
