﻿using System;

class ClassMain
{
    public static void Main(string[] args)
    {
        // Numero di ingresso
        int n = 5699821;
        // Variabile per memorizzare il numero invertito
        int reversed = 0;

        // Scorrere ogni cifra di n
        while (n > 0)
        {
            // Ottenere l'ultima cifra
            int lastDigit = n % 10;
            // Aggiunge l'ultima cifra al numero invertito
            reversed = reversed * 10 + lastDigit;
            // Rimuove l'ultima cifra da n
            n /= 10;
        }
        // Stampa il numero invertito
        Console.WriteLine(reversed);
    }
}

