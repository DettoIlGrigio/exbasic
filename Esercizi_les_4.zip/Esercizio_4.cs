﻿using System;

class ClassMain
{
    public static int Compute(int a, int b)
    {
        // Se b è uguale a 0, allora a è il MCD
        if (b == 0)
        {
            return a;
        }
        // Chiamata ricorsiva con i valori di a e b scambiati
        return Compute(b, a % b);
    }

    public static void Main(string[] args)
    {
        // Imposto manualmente i valori dei due int
        int a = 10;
        int b = 20;
        Console.WriteLine("MCD di " + a + " e " + b + " è: " + Compute(a, b));
    }
}
