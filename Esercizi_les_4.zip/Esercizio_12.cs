﻿/* Il programma chiede all'utente di inserire un numero intero positivo e lo memorizza nella variabile "num".
Poi crea una variabile "sum" per tenere traccia della somma dei divisori propri del numero.
Il ciclo for scorre da 1 fino a num-1, e per ogni numero che "num" è divisibile senza resto, aggiunge quel numero alla somma.
Una volta che la somma dei divisori propri è stata calcolata, il programma confronta la somma con il numero immesso dall'utente.
Se sono uguali, significa che il numero è perfetto, poiché la somma dei suoi divisori propri è uguale al numero stesso.
Se la somma è maggiore del numero, significa che è abbondante, poiché la somma dei suoi divisori propri è maggiore del numero stesso.
Se la somma è minore del numero, significa che è difettivo, poiché la somma dei suoi divisori propri è minore del numero stesso.
Il programma quindi visualizza un messaggio che indica se il numero è perfetto, abbondante o difettivo e poi attende che l'utente premi un tasto per uscire.*/

using System;

class ClassMain
{
    static void Main(string[] args)
    {
        // Chiediamo all'utente di inserire un numero intero positivo
        Console.WriteLine("Inserisci un numero intero positivo:");
        int num = int.Parse(Console.ReadLine());

        // Inizializziamo una variabile per tenere traccia della somma dei divisori propri
        int sum = 0;

        // Calcoliamo la somma dei divisori propri
        for (int i = 1; i < num; i++)
        {
            if (num % i == 0)
            {
                sum += i;
            }
        }

        // Verifichiamo se il numero è perfetto, abbondante o difettivo
        if (sum == num)
        {
            Console.WriteLine(num + " è un numero perfetto.");
        }
        else if (sum > num)
        {
            Console.WriteLine(num + " è un numero abbondante.");
        }
        else
        {
            Console.WriteLine(num + " è un numero difettivo.");
        }

        // Attendo che l'utente premi un tasto per uscire , so che ormai questa cosa non si usa più dalle versione nuove
        Console.ReadKey();
    }
}
