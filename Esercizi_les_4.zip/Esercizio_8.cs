﻿using System;

class ClassMain
{
    static void Main(string[] args)
    {
        int sum = 0;
        int input;

        // Richiedi all'utente l'input
        Console.WriteLine("Immettere una sequenza di numeri interi da aggiungere, separati premendo Invio.");
        Console.WriteLine("Premere 0 per interrompere");

        // Ricevi continuamente input dall'utente finché non viene inserito 0
        do
        {
            input = Convert.ToInt32(Console.ReadLine());
            if (input != 0)
            {
                sum += input;
            }
        } while (input != 0);

        // Stampa la somma degli interi inseriti
        Console.WriteLine("La somma degli interi è: " + sum);
    }
}

