﻿using System;

class ClassMain
{
    static void Main(string[] args)
    {
        // Variabile per memorizzare l'equivalente decimale del numero binario
        int decimalNumber = 0;
        // Variabile per memorizzare la potenza di 2
        int power = 0;

        Console.WriteLine("Immettere le cifre binarie (0 o 1) una alla volta, partendo dalla cifra meno significativa:");
        // Legge le cifre binarie una per volta
        while (true)
        {
            int binaryDigit = int.Parse(Console.ReadLine());
            // Se l'utente immette un numero diverso da 0 o 1, interrompe il ciclo
            if (binaryDigit != 0 && binaryDigit != 1)
                break;
            // Aggiunge la cifra binaria corrente moltiplicata per 2^potenza al numero decimale
            decimalNumber += binaryDigit * (int)Math.Pow(2, power); 
            power++;
        }
        Console.WriteLine("L'equivalente decimale del numero binario è: " + decimalNumber);
    }
}
