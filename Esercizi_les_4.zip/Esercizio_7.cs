﻿using System;

class ClassMain
{
    public static void Main(string[] args)
    {
        // Richiediamo all'utente di inserire il numero di elementi della sequenza
        Console.WriteLine("Inserisci il numero di elementi della sequenza:");
        int n = int.Parse(Console.ReadLine());

        // Inizializziamo la variabile per il prodotto totale
        int prodotto = 1;

        // Utilizziamo un ciclo for per richiedere all'utente di inserire ciascun elemento della sequenza
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Inserisci l'elemento " + (i + 1) + " della sequenza:");
            int elemento = int.Parse(Console.ReadLine());

            // Moltiplichiamo il prodotto per l'elemento corrente
            prodotto *= elemento;
        }

        // Stampiamo il prodotto totale
        Console.WriteLine("Il prodotto totale della sequenza è: " + prodotto);
    }
}
