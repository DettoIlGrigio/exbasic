﻿using System;

class ClassMain
{
    static void Main(string[] args)
    {
        // Chiediamo all'utente di inserire un numero in base 10
        Console.WriteLine("Inserisci un numero in base 10: ");
        int numeroDecimale = Convert.ToInt32(Console.ReadLine());

        // Creiamo una stringa vuota per contenere il numero binario
        string numeroBinario = "";

        // Utilizziamo un ciclo while per convertire il numero in base 10 in base 2
        while (numeroDecimale > 0)
        {
            // Utilizziamo l'operatore modulo per ottenere il resto della divisione del numero per 2
            int resto = numeroDecimale % 2;

            // Aggiungiamo il resto alla stringa binaria
            numeroBinario = resto + numeroBinario;

            // Dividiamo il numero per 2 utilizzando l'operatore di divisione intera
            numeroDecimale = numeroDecimale / 2;
        }

        // Stampiamo il risultato
        Console.WriteLine("Il numero in base 2 è: " + numeroBinario);
    }
}

