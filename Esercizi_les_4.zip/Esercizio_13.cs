﻿using System;

class ClassMain
{
    static void Main()
    {
        // Dichiarazione delle variabili
        int numero;
        int somma = 0;
        int contatore = 0;

        // Ciclo per la lettura dei numeri
        while (true)
        {
            Console.Write("Inserisci un numero: ");
            numero = int.Parse(Console.ReadLine());

            // Controllo per uscire dal ciclo
            if (numero < 0)
                break;

            // Somma dei numeri inseriti
            somma += numero;
            contatore++;

            // Calcolo e stampa della media
            if (contatore > 1)
            {
                double media = (double)somma / (contatore - 1);
                Console.WriteLine("La media finora è: {0}", media);
            }
        }
    }
}