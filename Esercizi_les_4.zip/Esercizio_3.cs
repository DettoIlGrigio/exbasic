﻿using System;

class ClassMain
{
    static void Main(string[] args)
    {
        int n;
        Console.WriteLine("Immettere il valore di n: ");
        n = int.Parse(Console.ReadLine());

        // Inizializza i primi due valori della sequenza di Fibonacci
        int a = 0, b = 1;
        int c;

        // Caso limite per n = 0
        if (n == 0)
        {
            Console.WriteLine("Il valore di an è: 0");
            return;
        }
        Console.Write(a + " " + b + " ");

        // Ciclo per calcolare e stampare i valori successivi della sequenza
        for (int i = 2; i < n; i++)
        {
            c = a + b;
            Console.Write(c + " ");
            a = b;
            b = c;
        }

        // Stampa il valore di an
        Console.WriteLine("\nIl valore di an è: " + b);
    }
}
