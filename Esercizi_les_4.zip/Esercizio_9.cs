﻿using System;

class ClassMain
{
    static void Main(string[] args)
    {
        // Variabile per tenere traccia dei numeri inseriti
        int num;
        // Variabile per tenere traccia della somma dei numeri inseriti
        int sum = 0;
        // Variabile per tenere traccia del numero di elementi nella sequenza
        int count = 0;
        // Variabile per tenere traccia del valore medio
        double average;

        // Chiediamo all'utente di inserire un numero
        Console.WriteLine("Inserisci un numero intero positivo: ");
        num = int.Parse(Console.ReadLine());

        // Continuiamo a chiedere numeri all'utente finché non inserisce un numero negativo
        while (num >= 0)
        {
            // Aggiungiamo il numero alla somma
            sum += num;
            // Aggiungiamo 1 al conteggio dei numeri
            count++;
            // Calcoliamo la media fino ad ora
            average = (double)sum / count;
            // Stampiamo la media solo a partire dal secondo numero
            if (count > 1)
            {
                Console.WriteLine("La media fino ad ora è: " + average);
            }
            // Chiediamo un altro numero all'utente
            Console.WriteLine("Inserisci un altro numero intero positivo: ");
            num = int.Parse(Console.ReadLine());
        }
    }
}
