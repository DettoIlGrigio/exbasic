﻿using System;

class ClassMain
{
    public static void Main(string[] args)
    {
        // Chiedi all'utente di inserire un numero intero non negativo a
        Console.WriteLine("Inserisci un numero intero non negativo a: ");
        int a = Convert.ToInt32(Console.ReadLine());

        // Chiedi all'utente di inserire un numero intero positivo d
        Console.WriteLine("Inserisci un numero intero positivo d: ");
        int d = Convert.ToInt32(Console.ReadLine());

        // Calcola il quoziente dividendo a per d
        int quoziente = a / d;

        // Calcola il resto utilizzando l'operatore di modulo su a e d
        int resto = a % d;

        // Stampa il quoziente e il resto sulla console
        Console.WriteLine("Quoziente: " + quoziente);
        Console.WriteLine("Resto: " + resto);
    }
}
